# OBJETIVO

Realizar a automação do processo de compra de ingressos no aplicativo do cinemark utilizando a linguagem Robot Framework

# INSTALAÇÃO

Windows

# Instalação do Python

* https://www.python.org/downloads/

# Validar instalação

* pip --version
* pip install robotframework
* pip install PyYAML

# Instalação das dependêcias do projeto

* pip install -r requirements.txt

requiriments.txt: arquivo dentro do projeto que contém todas as bibliotecas necessárias para a automação.

# Diretrizes para a criação dos testes

* Criação dos testes em gherkin utilizando técnica BDD.

# Bibliotecas utilizadas

* AppiumLibrary

# Como executar os testes

Passo 1: Baixe o projeto através do github

Passo 2: Abra o terminal para execução do script

Passo 3: Digite o comando robot -d ./results  tests

# Verificar as dependecias dependências 

* pip freeze

